async function start_icon_update() {

    const WORKDIR = "/mnt/sandbox/" + get_title_id() + "_000/download0/cache/splash_screen/";
    let FINAL_PATH =  WORKDIR + "aHR0cHM6Ly93d3cueW91dHViZS5jb20vdHY=";

    function read_file_to_buffer(path) {
        const path_addr = alloc_string(path);
        const stat_buf = malloc(0x200n);
        const stat_ret = syscall(SYSCALL.stat, path_addr, stat_buf);
        if (stat_ret !== 0n) {throw new Error("read_file_to_buffer: stat failed for " + path + " code: " + toHex(stat_ret));}
        const file_size = Number(read64(stat_buf + 72n));
        if (file_size < 0) {throw new Error("read_file_to_buffer: invalid file size " + file_size);}
        if (file_size === 0) {return { buffer: malloc(0n), size: 0 };}
        const fd = syscall(SYSCALL.open, path_addr, O_RDONLY, 0n);
        if (fd < 0n) {throw new Error("read_file_to_buffer: open failed for " + path + " fd: " + toHex(fd));}
        const file_buffer = malloc(BigInt(file_size));
        try {
            const bytes_read = syscall(SYSCALL.read, fd, file_buffer, BigInt(file_size));
            if (bytes_read < 0n) {throw new Error("read_file_to_buffer: read failed: " + toHex(bytes_read));}
            if (Number(bytes_read) !== file_size) {throw new Error(`read_file_to_buffer: incomplete read. Expected ${file_size}, got ${bytes_read}`);}
        }
        finally {syscall(SYSCALL.close, fd);}
        return { buffer: file_buffer, size: file_size };
    }
    
    
    function write_buffer_to_file(path, buffer_ptr, size) {
        const path_addr = alloc_string(path);
        const flags = O_WRONLY | O_CREAT | O_TRUNC;
        const mode = 0o755n;
        const fd = syscall(SYSCALL.open, path_addr, BigInt(flags), mode);
        if (fd < 0n) {
            const err = toHex(fd);
            log("[ERROR] open for write failed: " + path + " fd=" + err);
            send_notification("[ERROR] open for write failed: " + path + " fd=" + err);
            return false;
        }
        const wrote = syscall(SYSCALL.write, fd, buffer_ptr, BigInt(size));
        const closeRet = syscall(SYSCALL.close, fd);
        if (wrote < 0n) {
            const err = toHex(wrote);
            log("[ERROR] write failed for " + path + " -> " + err);
            send_notification("[ERROR] write failed for " + path + " -> " + err);
            return false;
        }
        if (wrote !== BigInt(size)) {
            log("[WARN] partial write for " + path + " wrote=" + wrote + " expected=" + size);
            send_notification("[WARN] partial write for " + path + " wrote=" + wrote + " expected=" + size);
            return false;
        }
        if (closeRet < 0n) {
            log("[WARN] close returned " + toHex(closeRet) + " for " + path);
            send_notification("[WARN] close returned " + toHex(closeRet) + " for " + path);
        }
        return true;
    }
    
    
    function compare_buffers(buf1_ptr, buf2_ptr, size) {
        const n = BigInt(size);
        for (let i = 0n; i < n; i++) {if (read8(buf1_ptr + i) !== read8(buf2_ptr + i)) {return false;}}
        return true;
    }
    
    
    function file_exists(path) {
        const path_addr = alloc_string(path);
        const stat_buf = malloc(0x200n);
        const ret = syscall(SYSCALL.stat, path_addr, stat_buf);
        return ret === 0n;
    }
    
    async function updateIcon() {
        const titleId = get_title_id();
        const iconPath = "/user/appmeta/" + titleId + "/icon0.png";
        const newIconPath = FINAL_PATH + "/icon0.png";
        const picZeroPNGPath = "/user/appmeta/" + titleId + "/pic0.png";
        const newPicZeroPNGPath = FINAL_PATH + "/pic0.png";
        const picZeroDDSPath = "/user/appmeta/" + titleId + "/pic0.dds";
        const newPicZeroDDSPath = FINAL_PATH + "/pic0.dds";
        const picOnePNGPath = "/user/appmeta/" + titleId + "/pic1.png";
        const newPicOnePNGPath = FINAL_PATH + "/pic1.png";
        const picOneDDSPath = "/user/appmeta/" + titleId + "/pic1.dds";
        const newPicOneDDSPath = FINAL_PATH + "/pic1.dds";
        const paramPath = "/user/appmeta/" + titleId + "/param.json";
        const newParamPath = FINAL_PATH + "/param.json";
        
        if (!file_exists(newIconPath)) {log("Kein icon0.png im Update-Paket: " + newIconPath);return null;}
        if (!file_exists(newPicZeroPNGPath)) {log("Kein pic0.png im Update-Paket: " + newPicZeroPNGPath);return null;}
        if (!file_exists(newPicZeroDDSPath)) {log("Kein pic0.dds im Update-Paket: " + newPicZeroDDSPath);return null;}
        if (!file_exists(newPicOnePNGPath)) {log("Kein pic1.png im Update-Paket: " + newPicOnePNGPath);return null;}
        if (!file_exists(newPicOneDDSPath)) {log("Kein pic1.dds im Update-Paket: " + newPicOneDDSPath);return null;}
        if (!file_exists(newParamPath)) {log("Kein param.json im Update-Paket: " + newParamPath);return null;}
        
        let iconPS = null;let iconUpdate = null;let iconSame = false;
        let picZeroPNGPS = null;let picZeroPNGUpdatePS = null;let picZeroPNGSame = false;
        let picZeroDDSPS = null;let picZeroDDSUpdatePS = null;let picZeroDDSSame = false;
        let picOnePNGPS = null;let picOnePNGUpdate = null;let picOnePNGSame = false;
        let picOneDDSPS = null;let picOneDDSUpdate = null;let picOneDDSSame = false;
        let paramPS = null;let paramUpdate = null;let paramSame = false;
        
        try {
            // icon0.png
            log("Datei-Check Update icon0.png: " + newIconPath);
            iconUpdate = read_file_to_buffer(newIconPath);
            log("Update icon0.png: " + iconUpdate.size + " bytes");
            if (!file_exists(iconPath)) {
                log("icon0.png fehlt auf der PS5. Datei wird angelegt...");
                const writeSuccess = write_buffer_to_file(iconPath, iconUpdate.buffer, iconUpdate.size);
                if (writeSuccess) {log("icon0.png erfolgreich angelegt: " + iconPath);send_notification("icon0.png: Datei angelegt.");}
                else {log("icon0.png konnte nicht angelegt werden: " + iconPath);}
            }
            else {
                log("Datei-Check PS5 icon0.png: " + iconPath);
                iconPS = read_file_to_buffer(iconPath);
                log("PS5 icon0.png: " + iconPS.size + " bytes");
                if (iconPS.size !== iconUpdate.size) {log("Byte-Unterschiede erkannt...");iconSame = false;}
                else {log("Bytes werden verglichen...");iconSame = compare_buffers(iconPS.buffer, iconUpdate.buffer, iconPS.size);}
                if (!iconSame) {
                    log("icon0.png wird kopiert...");
                    const writeSuccess = write_buffer_to_file(iconPath, iconUpdate.buffer, iconUpdate.size);
                    if (writeSuccess) {log("icon0.png erfolgreich kopiert nach: " + iconPath);send_notification("icon0.png: Update erfolgreich.");}
                    else {log("icon0.png: Fehler bei: " + iconPath);}
                }
                else {log("icon0.png identisch. Update nicht notwendig.");}
            }
            
            // pic0.png
            log("Datei-Check Update pic0.png: " + newPicZeroPNGPath);
            picZeroPNGUpdatePS = read_file_to_buffer(newPicZeroPNGPath);
            log("Update pic0.png: " + picZeroPNGUpdatePS.size + " bytes");
            if (!file_exists(picZeroPNGPath)) {
                log("pic0.png fehlt auf der PS5. Datei wird angelegt...");
                const writeSuccess = write_buffer_to_file(picZeroPNGPath, picZeroPNGUpdatePS.buffer, picZeroPNGUpdatePS.size);
                if (writeSuccess) {log("pic0.png erfolgreich angelegt: " + picZeroPNGPath);send_notification("pic0.png: Datei angelegt.");}
                else {log("pic0.png konnte nicht angelegt werden: " + picZeroPNGPath);}
            }
            else {
                log("Datei-Check PS5 pic0.png: " + picZeroPNGPath);
                picZeroPNGPS = read_file_to_buffer(picZeroPNGPath);
                log("PS5 pic0.png: " + picZeroPNGPS.size + " bytes");
                if (picZeroPNGPS.size !== picZeroPNGUpdatePS.size) {log("Byte-Unterschiede erkannt...");picZeroPNGSame = false;}
                else {log("Bytes werden verglichen...");picZeroPNGSame = compare_buffers(picZeroPNGPS.buffer, picZeroPNGUpdatePS.buffer, picZeroPNGPS.size);}
                if (!picZeroPNGSame) {
                    log("pic0.png wird kopiert...");
                    const writeSuccess = write_buffer_to_file(picZeroPNGPath, picZeroPNGUpdatePS.buffer, picZeroPNGUpdatePS.size);
                    if (writeSuccess) {log("pic0.png erfolgreich kopiert nach: " + picZeroPNGPath);send_notification("pic0.png: Update erfolgreich.");}
                    else {log("pic0.png: Fehler bei: " + picZeroPNGPath);}
                }
                else {log("pic0.png identisch. Update nicht notwendig.");}
            }

            // pic0.dds
            log("Datei-Check Update pic0.dds: " + newPicZeroDDSPath);
            picZeroDDSUpdatePS = read_file_to_buffer(newPicZeroDDSPath);
            log("Update pic0.dds: " + picZeroDDSUpdatePS.size + " bytes");
            if (!file_exists(picZeroDDSPath)) {
                log("pic0.dds fehlt auf der PS5. Datei wird angelegt...");
                const writeSuccess = write_buffer_to_file(picZeroDDSPath, picZeroDDSUpdatePS.buffer, picZeroDDSUpdatePS.size);
                if (writeSuccess) {log("pic0.dds erfolgreich angelegt: " + picZeroDDSPath);send_notification("pic0.dds: Datei angelegt.");}
                else {log("pic0.dds konnte nicht angelegt werden: " + picZeroDDSPath);}
            }
            else {
                log("Datei-Check PS5 pic0.dds: " + picZeroDDSPath);
                picZeroDDSPS = read_file_to_buffer(picZeroDDSPath);
                log("PS5 pic0.dds: " + picZeroDDSPS.size + " bytes");
                if (picZeroDDSPS.size !== picZeroDDSUpdatePS.size) {log("Byte-Unterschiede erkannt...");picZeroDDSSame = false;}
                else {log("Bytes werden verglichen...");picZeroDDSSame = compare_buffers(picZeroDDSPS.buffer, picZeroDDSUpdatePS.buffer, picZeroDDSPS.size);}
                if (!picZeroDDSSame) {
                    log("pic0.dds wird kopiert...");
                    const writeSuccess = write_buffer_to_file(picZeroDDSPath, picZeroDDSUpdatePS.buffer, picZeroDDSUpdatePS.size);
                    if (writeSuccess) {log("pic0.dds erfolgreich kopiert nach: " + picZeroDDSPath);send_notification("pic0.dds: Update erfolgreich.");}
                    else {log("pic0.dds: Fehler bei: " + picZeroDDSPath);}
                }
                else {log("pic0.dds identisch. Update nicht notwendig.");}
            }
            
            // pic1.png
            log("Datei-Check Update pic1.png: " + newPicOnePNGPath);
            picOnePNGUpdate = read_file_to_buffer(newPicOnePNGPath);
            log("Update pic1.png: " + picOnePNGUpdate.size + " bytes");
            if (!file_exists(picOnePNGPath)) {
                log("pic1.png fehlt auf der PS5. Datei wird angelegt...");
                const writeSuccess = write_buffer_to_file(picOnePNGPath, picOnePNGUpdate.buffer, picOnePNGUpdate.size);
                if (writeSuccess) {log("pic1.png erfolgreich angelegt: " + picOnePNGPath);send_notification("pic1.png: Datei angelegt.");}
                else {log("pic1.png konnte nicht angelegt werden: " + picOnePNGPath);}
            }
            else {
                log("Datei-Check PS5 pic1.png: " + picOnePNGPath);
                picOnePNGPS = read_file_to_buffer(picOnePNGPath);
                log("PS5 pic1.png: " + picOnePNGPS.size + " bytes");
                if (picOnePNGPS.size !== picOnePNGUpdate.size) {log("Byte-Unterschiede erkannt...");picOnePNGSame = false;}
                else {log("Bytes werden verglichen...");picOnePNGSame = compare_buffers(picOnePNGPS.buffer, picOnePNGUpdate.buffer, picOnePNGPS.size);}
                if (!picOnePNGSame) {
                    log("pic1.png wird kopiert...");
                    const writeSuccess = write_buffer_to_file(picOnePNGPath, picOnePNGUpdate.buffer, picOnePNGUpdate.size);
                    if (writeSuccess) {log("pic1.png erfolgreich kopiert nach: " + picOnePNGPath);send_notification("pic1.png: Update erfolgreich.");}
                    else {log("pic1.png: Fehler bei: " + picOnePNGPath);}
                }
                else {log("pic1.png identisch. Update nicht notwendig.");}
            }

            // pic1.dds
            log("Datei-Check Update pic1.dds: " + newPicOneDDSPath);
            picOneDDSUpdate = read_file_to_buffer(newPicOneDDSPath);
            log("Update pic1.dds: " + picOneDDSUpdate.size + " bytes");
            if (!file_exists(picOneDDSPath)) {
                log("pic1.dds fehlt auf der PS5. Datei wird angelegt...");
                const writeSuccess = write_buffer_to_file(picOneDDSPath, picOneDDSUpdate.buffer, picOneDDSUpdate.size);
                if (writeSuccess) {log("pic1.dds erfolgreich angelegt: " + picOneDDSPath);send_notification("pic1.dds: Datei angelegt.");}
                else {log("pic1.dds konnte nicht angelegt werden: " + picOneDDSPath);}
            }
            else {
                log("Datei-Check PS5 pic1.dds: " + picOneDDSPath);
                picOneDDSPS = read_file_to_buffer(picOneDDSPath);
                log("PS5 pic1.dds: " + picOneDDSPS.size + " bytes");
                if (picOneDDSPS.size !== picOneDDSUpdate.size) {log("Byte-Unterschiede erkannt...");picOneDDSSame = false;}
                else {log("Bytes werden verglichen...");picOneDDSSame = compare_buffers(picOneDDSPS.buffer, picOneDDSUpdate.buffer, picOneDDSPS.size);}
                if (!picOneDDSSame) {
                    log("pic1.dds wird kopiert...");
                    const writeSuccess = write_buffer_to_file(picOneDDSPath, picOneDDSUpdate.buffer, picOneDDSUpdate.size);
                    if (writeSuccess) {log("pic1.dds erfolgreich kopiert nach: " + picOneDDSPath);send_notification("pic1.dds: Update erfolgreich.");}
                    else {log("pic1.dds: Fehler bei: " + picOneDDSPath);}
                }
                else {log("pic1.dds identisch. Update nicht notwendig.");}
            }
            
            // param.json
            log("Datei-Check Update param.json: " + newParamPath);
            paramUpdate = read_file_to_buffer(newParamPath);
            log("Update param.json: " + paramUpdate.size + " bytes");
            if (!file_exists(paramPath)) {
                log("param.json fehlt auf der PS5. Datei wird angelegt...");
                const writeSuccess = write_buffer_to_file(paramPath, paramUpdate.buffer, paramUpdate.size);
                if (writeSuccess) {log("param.json erfolgreich angelegt: " + paramPath);send_notification("param.json: Datei angelegt.");}
                else {log("param.json konnte nicht angelegt werden: " + paramPath);}
            }
            else {
                log("Datei-Check PS5 param.json: " + paramPath);
                paramPS = read_file_to_buffer(paramPath);
                log("PS5 param.json: " + paramPS.size + " bytes");
                if (paramPS.size !== paramUpdate.size) {log("Byte-Unterschiede erkannt...");paramSame = false;}
                else {log("Bytes werden verglichen...");paramSame = compare_buffers(paramPS.buffer, paramUpdate.buffer, paramPS.size);}
                if (!paramSame) {
                    log("param.json wird kopiert...");
                    const writeSuccess = write_buffer_to_file(paramPath, paramUpdate.buffer, paramUpdate.size);
                    if (writeSuccess) {log("param.json erfolgreich kopiert nach: " + paramPath);send_notification("param.json: Update erfolgreich.");}
                    else {log("param.json: Fehler bei: " + paramPath);}
                }
                else {log("param.json identisch. Update nicht notwendig.");}
            }
        } catch (e) {
            const msg = (e && e.message) ? e.message : String(e);
            log("Updater-Fehler: " + msg);
            send_notification("Updater-Fehler: " + msg);
        }
    }
    await updateIcon();
}
