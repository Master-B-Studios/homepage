@echo off
setlocal enabledelayedexpansion

echo ============================================
echo      Y2JB Update Generator (Windows)
echo ============================================
echo.

:: Basisordner
set "BASE_DIR=%~dp0"
set "UPDATE_DIR=%BASE_DIR%y2jb_update"
set "INFO_FILE=%UPDATE_DIR%\update-info.txt"
set "ZIP_FILE=%BASE_DIR%y2jb_update.zip"
set "ZIP_EXE=%BASE_DIR%sources\7za.exe"

:: Prüfen ob y2jb_update existiert
if not exist "%UPDATE_DIR%" (
    echo FEHLER: Ordner y2jb_update wurde nicht gefunden!
    echo Bitte stelle sicher, dass dieser Ordner in Updater/ liegt.
    pause
    exit /b 1
)

:: Prüfen ob 7z.exe existiert
if not exist "%ZIP_EXE%" (
    echo FEHLER: 7z.exe wurde nicht gefunden!
    echo Erwarte: Updater\sources\7za.exe
    pause
    exit /b 1
)

echo Erstelle update-info.txt...
echo.

:: alte update-info.txt löschen
if exist "%INFO_FILE%" del "%INFO_FILE%"

:: In y2jb_update wechseln
pushd "%UPDATE_DIR%"

:: Rekursiv alle Dateien sammeln, aber update-info.txt ausschließen
for /f "delims=" %%F in ('dir /b /s /a-d ^| sort') do (
    set "FULL=%%F"
    set "REL=!FULL:%UPDATE_DIR%\=!"
    
    :: Backslashes durch Slashes ersetzen
    set "REL=!REL:\=/!"

    :: update-info.txt überspringen
    if /i not "!REL!"=="update-info.txt" (
        for %%S in ("%%F") do (
            echo !REL!^|%%~zS>> "%INFO_FILE%"
        )
    )
)

popd

echo update-info.txt wurde erfolgreich erstellt.
echo.

:: alte ZIP löschen
if exist "%ZIP_FILE%" del "%ZIP_FILE%"

echo Erstelle ZIP-Archiv...
echo.

"%ZIP_EXE%" a -tzip "%ZIP_FILE%" "%UPDATE_DIR%\*" -r >nul

if %errorlevel% neq 0 (
    echo FEHLER: ZIP konnte nicht erstellt werden!
    pause
    exit /b 1
)

echo ============================================
echo   Fertig! ZIP erstellt:
echo   %ZIP_FILE%
echo ============================================

pause
