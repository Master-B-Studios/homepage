#!/bin/bash
set -e

echo "============================================"
echo "     Y2JB Update Generator (macOS)"
echo "============================================"
echo

# Basisordner = Verzeichnis, in dem dieses Script liegt
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
UPDATE_DIR="$BASE_DIR/y2jb_update"
INFO_FILE="$UPDATE_DIR/update-info.txt"
ZIP_FILE="$BASE_DIR/y2jb_update.zip"

# Prüfen ob y2jb_update existiert
if [ ! -d "$UPDATE_DIR" ]; then
    echo "FEHLER: Ordner y2jb_update wurde nicht gefunden!"
    echo "Bitte stelle sicher, dass dieser Ordner neben dem Script liegt."
    exit 1
fi

echo "Erstelle update-info.txt..."
echo

# Alte update-info.txt löschen
rm -f "$INFO_FILE"

# Alle Dateien rekursiv sammeln, sortieren und update-info.txt ausschließen
cd "$UPDATE_DIR"

find . -type f ! -name "update-info.txt" | sort | while IFS= read -r FILE; do

    # ./ am Anfang entfernen
    REL="${FILE#./}"

    # Dateigröße ermitteln (macOS/BSD stat)
    SIZE=$(stat -f "%z" "$FILE")

    echo "${REL}|${SIZE}" >> "$INFO_FILE"

done

echo "update-info.txt wurde erfolgreich erstellt."
echo

# Altes ZIP löschen
rm -f "$ZIP_FILE"

echo "Erstelle ZIP-Archiv..."
echo

# ZIP aus dem Inhalt von y2jb_update erstellen
cd "$UPDATE_DIR"
zip -r -q "$ZIP_FILE" .

# Prüfen
if [ $? -ne 0 ]; then
    echo "FEHLER: ZIP konnte nicht erstellt werden!"
    exit 1
fi

echo "============================================"
echo "  Fertig! ZIP erstellt:"
echo "  $ZIP_FILE"
echo "============================================"