# PS5 UMTX Jailbreak

The exploit code is largely based on the lua implementation by @shahrilnet and @n0llptr: https://github.com/shahrilnet/remote_lua_loader/blob/main/payloads/umtx.lua

The rest of the setup is based on the previous works by @SpecterDev and @ChendoChap: https://github.com/PS5Dev/PS5-UMTX-Jailbreak/

Thank you to them and everyone else who worked on the umtx and psfree exploit!

- Supports PS5 firmware 1.00-5.50
- Includes payload menu
- Uses PSFree 150b by abc
- Auto-loads @john-tornblom's ELF loader
- Includes the 9020 elf loader for compatibility with older payloads (not available in webkit-only mode)
- Webkit-only mode for sending payloads and clearing appcache

### Site hosted on CloudFlare Pages: [https://umtx2.pages.dev/](https://umtx2.pages.dev/)
   - Media pkg to open a browser directly at this link: [https://umtx2.ps5browser.pages.dev/umtx2.pages.dev.pkg](https://umtx2.ps5browser.pages.dev/umtx2.pages.dev.pkg)

### Site hosted on GitHub Pages: [https://idlesauce.github.io/umtx2/](https://idlesauce.github.io/umtx2/)
   - Media pkg to open a browser directly at this link: [https://umtx2.ps5browser.pages.dev/umtx2.github.pkg](https://umtx2.ps5browser.pages.dev/umtx2.github.pkg)